.\scripts\flosi-qa.ps1 -Action Prepare
.\scripts\flosi-qa.ps1 -Action Check
.\scripts\flosi-qa.ps1 -Action Run
