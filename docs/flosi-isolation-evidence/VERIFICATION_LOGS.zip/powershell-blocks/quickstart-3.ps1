node .\scripts\flosi-qa.js prepare
if ($LASTEXITCODE -ne 0) { throw 'Preparación fallida; revisar el error antes de continuar.' }
node .\scripts\flosi-qa.js check
if ($LASTEXITCODE -ne 0) { throw 'Preflight fallido; no iniciar.' }
node .\scripts\flosi-qa.js run
