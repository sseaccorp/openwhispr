$qaRoot = Join-Path $env:LOCALAPPDATA 'FlosiQA' # usar la misma DataRoot de Prepare
$marker = Get-Content -LiteralPath (Join-Path $qaRoot 'flosi-qa.json') -Raw | ConvertFrom-Json
if ($marker.appId -ne 'com.sseaccorp.flosi.qa' -or $marker.variant -ne 'qa') { throw 'Raíz QA inválida.' }
$officialRoots = @(
    (Join-Path $env:APPDATA 'OpenWhispr'),
    (Join-Path $env:APPDATA 'open-whispr'),
    (Join-Path $env:APPDATA 'OpenWhispr-development'),
    (Join-Path $env:APPDATA 'OpenWhispr-staging'),
    (Join-Path $env:USERPROFILE '.cache\openwhispr'),
    (Join-Path $env:USERPROFILE '.openwhispr'),
    (Join-Path $env:LOCALAPPDATA 'OpenWhispr'),
    (Join-Path $env:LOCALAPPDATA 'openwhispr-updater'),
    (Join-Path $env:ProgramData 'OpenWhispr'),
    (Join-Path $env:SystemDrive 'OpenWhispr')
) | Sort-Object -Unique
function Save-OfficialProof([ValidateSet('before','after')][string]$Moment) {
    $ErrorActionPreference = 'Stop'
    $output = Join-Path $qaRoot ("logs\official-" + $Moment + '.json')
    $ancestor = Split-Path -Parent $output
    while ($ancestor) {
        if ((Get-Item -LiteralPath $ancestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Salida con enlace/junction.' }
        $parent = Split-Path -Parent $ancestor
        if ($parent -eq $ancestor) { break }
        $ancestor = $parent
    }
    $rows = @()
    foreach ($root in $officialRoots) {
        if (-not (Test-Path -LiteralPath $root)) { $rows += [pscustomobject]@{Path=$root;Hash='ABSENT'}; continue }
        $queue = New-Object 'System.Collections.Generic.Stack[string]'
        $queue.Push($root)
        while ($queue.Count -gt 0) {
            $entry = Get-Item -LiteralPath $queue.Pop() -Force
            if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Referencia con enlace: $($entry.FullName)" }
            if ($entry.PSIsContainer) {
                $rows += [pscustomobject]@{Path=$entry.FullName;Hash='DIRECTORY'}
                foreach ($child in Get-ChildItem -LiteralPath $entry.FullName -Force) { $queue.Push($child.FullName) }
            } else {
                $rows += [pscustomobject]@{Path=$entry.FullName;Hash=(Get-FileHash -LiteralPath $entry.FullName -Algorithm SHA256).Hash}
            }
        }
    }
    $stream = [IO.File]::Open($output, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    $writer = New-Object IO.StreamWriter($stream)
    try { $writer.Write(($rows | Sort-Object Path | ConvertTo-Json -Depth 4)) } finally { $writer.Dispose() }
}
Save-OfficialProof before
# Ejecutar QA; salir normalmente. Mantener oficial cerrado. Después:
# Save-OfficialProof after
# Compare-Object (Get-Content -Raw (Join-Path $qaRoot 'logs\official-before.json')) (Get-Content -Raw (Join-Path $qaRoot 'logs\official-after.json'))
