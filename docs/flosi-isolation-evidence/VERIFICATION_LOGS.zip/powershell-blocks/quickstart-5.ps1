.\scripts\flosi-qa.ps1 -Action Prepare -Cuda
.\scripts\flosi-qa.ps1 -Action Run
