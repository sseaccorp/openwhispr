$qaRoot = 'D:\FlosiQA-private'
.\scripts\flosi-qa.ps1 -Action Prepare -DataRoot $qaRoot
.\scripts\flosi-qa.ps1 -Action Check -DataRoot $qaRoot
.\scripts\flosi-qa.ps1 -Action Run -DataRoot $qaRoot
