.\scripts\flosi-qa.ps1 -Action Prepare -LocalAI
.\scripts\flosi-qa.ps1 -Action Run
