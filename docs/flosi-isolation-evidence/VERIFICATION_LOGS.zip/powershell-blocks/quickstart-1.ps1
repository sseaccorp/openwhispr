$ErrorActionPreference = 'Stop'
$checkout = Join-Path $env:USERPROFILE 'source\flosi-qa-openwhispr'
if (Test-Path -LiteralPath $checkout) { throw 'La carpeta existe; preservarla y elegir un checkout nuevo.' }
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $checkout) | Out-Null
git clone --branch codex/flosi-windows-isolation --single-branch https://github.com/sseaccorp/openwhispr.git $checkout
if ($LASTEXITCODE -ne 0) { throw 'Falló git clone.' }
Set-Location -LiteralPath $checkout
$qaCommit = (git rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $qaCommit -notmatch '^[a-f0-9]{40}$') { throw 'Commit inválido.' }
Write-Host "Revisar este commit antes de preparar: $qaCommit"
git checkout --detach $qaCommit
if ($LASTEXITCODE -ne 0) { throw 'Falló checkout del commit exacto.' }
