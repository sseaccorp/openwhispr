$ErrorActionPreference = 'Stop'
$files = Get-ChildItem -LiteralPath /workspace/work/flosi-phase3/powershell-blocks-final -Filter '*.ps1'
$count = 0
foreach ($file in $files) {
  $tokens = $null; $errors = $null
  [System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors) | Out-Null
  if ($errors.Count -gt 0) { throw (($errors | ForEach-Object { $_.Message }) -join '; ') }
  $count++
}
Write-Output "PowerShell syntax parsed: $count files; Windows APIs not executed."
