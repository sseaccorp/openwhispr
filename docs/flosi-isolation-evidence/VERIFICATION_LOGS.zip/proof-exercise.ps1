$ErrorActionPreference = 'Stop'
$fixture = Join-Path '/workspace/work/flosi-phase3' ('proof-' + [guid]::NewGuid().ToString('N'))
$env:APPDATA = Join-Path $fixture 'roaming'
$env:LOCALAPPDATA = Join-Path $fixture 'local'
$env:USERPROFILE = Join-Path $fixture 'profile'
$env:ProgramData = Join-Path $fixture 'programdata'
$env:SystemDrive = Join-Path $fixture 'systemdrive'
$privateRoot = Join-Path $env:LOCALAPPDATA 'FlosiQA'
New-Item -ItemType Directory -Force -Path (Join-Path $privateRoot 'logs') | Out-Null
@{appId='com.sseaccorp.flosi.qa';variant='qa'} | ConvertTo-Json | Set-Content (Join-Path $privateRoot 'flosi-qa.json')
$reference = Join-Path $env:APPDATA 'OpenWhispr'
New-Item -ItemType Directory -Force -Path $reference | Out-Null
Set-Content (Join-Path $reference 'synthetic-reference.txt') 'synthetic original'
$block = (Get-Content '/workspace/work/flosi-phase3/proof-block-path.txt' -Raw).Trim()
. $block
Save-OfficialProof after
$before = Get-Content -Raw (Join-Path $privateRoot 'logs/official-before.json')
$after = Get-Content -Raw (Join-Path $privateRoot 'logs/official-after.json')
if ($before -ne $after) { throw 'Unchanged reference produced a mismatch.' }
$refused = $false
try { Save-OfficialProof before } catch { $refused = $true }
if (-not $refused) { throw 'Proof overwrote existing output.' }
Write-Output 'Synthetic proof capture/compare and overwrite refusal passed on Linux; Windows not executed.'
