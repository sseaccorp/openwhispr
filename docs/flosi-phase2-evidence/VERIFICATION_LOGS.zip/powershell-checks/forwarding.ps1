function npm.cmd {
    $global:QaCapturedArguments = @($args)
    $global:LASTEXITCODE = 0
}
function Invoke-QaNpm {
    param([Parameter(ValueFromRemainingArguments=$true)][string[]]$QaArguments)
    & npm.cmd @QaArguments
    if ($LASTEXITCODE -ne 0) { throw "npm falló: $QaArguments" }
}
Invoke-QaNpm run download:embedding-model '--' '--for-build'
if ((ConvertTo-Json -Compress -InputObject $global:QaCapturedArguments) -ne '["run","download:embedding-model","--","--for-build"]') { throw 'Incorrect embedding-model argument forwarding' }
Invoke-QaNpm run download:diarization-models '--' '--output-dir' 'resources/bin/diarization-models'
if ((ConvertTo-Json -Compress -InputObject $global:QaCapturedArguments) -ne '["run","download:diarization-models","--","--output-dir","resources/bin/diarization-models"]') { throw 'Incorrect diarization argument forwarding' }
'Argument forwarding simulation passed; no Windows command executed.'
