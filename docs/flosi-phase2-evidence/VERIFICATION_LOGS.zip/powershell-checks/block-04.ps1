$QaManifest = [ordered]@{
    sourceCommit = (git rev-parse HEAD).Trim()
    lockSha256 = (Get-FileHash package-lock.json -Algorithm SHA256).Hash
    windows = (Get-CimInstance Win32_OperatingSystem).Version
    node = (& node --version)
    npm = (& npm.cmd --version)
    profileSid = $QaIdentity.User.Value
    tempPath = $env:TEMP
    channel = $env:OPENWHISPR_CHANNEL
    nativeTests = 'pendientes: adjuntar resultados, esta plantilla no certifica éxito'
}
$QaManifest | ConvertTo-Json | Set-Content (Join-Path $QaLogs 'manifest.json')
Get-ChildItem resources\bin -File -Recurse | Where-Object { $_.Extension -in '.exe','.dll' } |
    Get-FileHash -Algorithm SHA256 | Export-Csv (Join-Path $QaLogs 'binaries.csv') -NoTypeInformation
