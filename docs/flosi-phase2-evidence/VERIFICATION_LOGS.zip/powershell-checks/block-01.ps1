Invoke-QaNpm rebuild better-sqlite3
$env:REQUIRE_DB_TESTS = '1'
node --import tsx --test --test-concurrency=4 "test/**/*.test.js" *> (Join-Path $QaLogs 'tests.txt')
if ($LASTEXITCODE -ne 0) { throw 'Falló la suite; conservar su log.' }
Remove-Item Env:REQUIRE_DB_TESTS
Invoke-QaNpm run build:renderer
# Restaurar la ABI Electron antes de arrancar el escritorio:
& .\node_modules\.bin\electron-builder.cmd install-app-deps
if ($LASTEXITCODE -ne 0) { throw 'No abrir Electron con ABI incorrecta de SQLite.' }
