$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Se requiere Windows.' }
$QaIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$QaProfilePath = [Environment]::GetFolderPath('UserProfile')
if ($QaIdentity.Name.Split('\')[-1] -ne 'FlosiQA' -or
    $QaProfilePath -ne 'C:\Users\FlosiQA' -or $QaProfilePath -match '[^\x21-\x7E]') {
    throw 'Usar la cuenta QA real y su perfil ASCII, no variables que simulen otro perfil.'
}
if ($env:OPENWHISPR_CACHE_ROOT) { throw 'Override de cache heredado: revisar en una sesión QA limpia.' }
$QaInheritedNames = 'GH_TOKEN','GITHUB_TOKEN','OPENAI_API_KEY','ANTHROPIC_API_KEY',
    'GROQ_API_KEY','GEMINI_API_KEY','HF_TOKEN','OPENWHISPR_API_URL','VITE_OPENWHISPR_API_URL'
foreach ($QaEnvName in $QaInheritedNames) {
    if ([Environment]::GetEnvironmentVariable($QaEnvName)) {
        throw "Configuración externa heredada: $QaEnvName. No imprimir su valor."
    }
}
$QaRoot = Join-Path $QaProfilePath 'FlosiQA'
$QaLogs = Join-Path $QaRoot 'logs'
$QaTemp = Join-Path $env:LOCALAPPDATA 'FlosiQA\Temp'
New-Item -ItemType Directory -Force -Path $QaRoot,$QaLogs,$QaTemp | Out-Null
if ($QaTemp -match '[^\x21-\x7E]') { throw 'TEMP debe ser privado y ASCII.' }
$env:TEMP = $QaTemp
$env:TMP = $QaTemp
$env:npm_config_cache = Join-Path $env:LOCALAPPDATA 'FlosiQA\npm-cache'
$env:NODE_ENV = 'development'
$env:OPENWHISPR_CHANNEL = 'development'
$QaOtherProcesses = Get-Process -ErrorAction SilentlyContinue | Where-Object {
    $_.ProcessName -match '^(OpenWhispr|electron|whisper-server.*|llama-server.*|sherpa-onnx.*|qdrant.*|windows-key-listener|windows-mic-listener|windows-system-audio-helper)$'
}
if ($QaOtherProcesses) {
    $QaOtherProcesses | Select-Object Id,ProcessName
    throw 'Cerrar apps/sidecars desde su propia sesión; no matar procesos ajenos.'
}
quser
whoami /user
$QaSource = Join-Path $QaRoot 'openwhispr'
if (Test-Path $QaSource) { throw 'El destino existe. Revisar o elegir checkout nuevo; no sobrescribir.' }
git clone --no-checkout https://github.com/sseaccorp/openwhispr.git $QaSource
if ($LASTEXITCODE -ne 0) { throw 'Falló clone.' }
Set-Location $QaSource
git fetch origin codex/flosi-baseline
if ($LASTEXITCODE -ne 0) { throw 'Falló fetch.' }
# Comprobar que este SHA coincide con el commit de preparación revisado en el PR.
$QaCommit = (git rev-parse origin/codex/flosi-baseline).Trim()
if ($QaCommit -notmatch '^[0-9a-f]{40}$') { throw 'SHA no válido.' }
git switch --detach $QaCommit
if ($LASTEXITCODE -ne 0) { throw 'Falló checkout del SHA exacto.' }
git merge-base --is-ancestor 300375424f8a2f8e0c8a602a27cab9ca9637620a HEAD
if ($LASTEXITCODE -ne 0) { throw 'No conserva la auditoría.' }
if (git status --porcelain) { throw 'El checkout no está limpio.' }
if ((git remote get-url origin).Trim() -ne 'https://github.com/sseaccorp/openwhispr.git') { throw 'Remoto inesperado.' }
$QaExpectedLock = '9dfb56d340c4e7490ea88a0d819dd38ad273a788ea10ab0431d913369ea97a92'
if ((Get-FileHash package-lock.json -Algorithm SHA256).Hash.ToLowerInvariant() -ne $QaExpectedLock) { throw 'Lockfile distinto al revisado.' }
$QaCommit | Set-Content (Join-Path $QaLogs 'source-commit.txt')
git remote -v
git status --short
node --version
npm.cmd --version
function Invoke-QaNpm {
    param([Parameter(ValueFromRemainingArguments=$true)][string[]]$QaArguments)
    & npm.cmd @QaArguments
    if ($LASTEXITCODE -ne 0) { throw "npm falló: $QaArguments" }
}
Invoke-QaNpm ci
Invoke-QaNpm run quality-check
Invoke-QaNpm run i18n:check
npm.cmd audit --audit-level=high --json | Set-Content (Join-Path $QaLogs 'npm-audit.json')
$QaAuditExit = $LASTEXITCODE
"npm audit exit=$QaAuditExit" | Set-Content (Join-Path $QaLogs 'npm-audit-exit.txt')
# Exit 1 sigue esperado por riesgos pendientes; no ocultarlo como aprobado.
if ($QaAuditExit -gt 1) { throw 'Audit no completó: revisar conexión/error.' }
