nvidia-smi.exe --query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu --format=csv
if ($LASTEXITCODE -ne 0) { throw 'GPU no medida; pendiente.' }
# Ctrl+C termina la captura de métricas, no el driver.
nvidia-smi.exe --query-gpu=timestamp,name,driver_version,memory.used,utilization.gpu,temperature.gpu --format=csv -l 1 |
    Tee-Object -FilePath (Join-Path $QaLogs 'gpu.csv')
