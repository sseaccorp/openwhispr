Invoke-QaNpm run compile:native
Invoke-QaNpm run download:whisper-cpp
Invoke-QaNpm run download:llama-server
Invoke-QaNpm run download:sherpa-onnx
Invoke-QaNpm run download:windows-fast-paste
Invoke-QaNpm run download:windows-key-listener
Invoke-QaNpm run download:windows-mic-listener
Invoke-QaNpm run download:windows-system-audio-helper
Invoke-QaNpm run download:nircmd
Invoke-QaNpm run download:meeting-aec-helper
Invoke-QaNpm run download:qdrant
Invoke-QaNpm run download:embedding-model '--' '--for-build'
Invoke-QaNpm run download:whisper-vad-model
Invoke-QaNpm run download:diarization-models '--' '--output-dir' 'resources/bin/diarization-models'
$QaRequired = 'whisper-server-win32-x64.exe','sherpa-onnx-ws-win32-x64.exe',
    'windows-key-listener.exe','windows-fast-paste.exe','windows-mic-listener.exe',
    'windows-system-audio-helper.exe','nircmd.exe'
foreach ($QaBinary in $QaRequired) {
    $QaBinaryPath = Join-Path 'resources\bin' $QaBinary
    if (!(Test-Path $QaBinaryPath) -or (Get-Item $QaBinaryPath).Length -eq 0) {
        throw "Falta artefacto requerido: $QaBinary"
    }
}
$env:NODE_ENV = 'development'
$env:OPENWHISPR_CHANNEL = 'development'
Invoke-QaNpm run dev
