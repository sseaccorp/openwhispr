import hashlib
import html
import json
import pathlib
import re
import urllib.request

root = pathlib.Path('/workspace/work/flosi-phase2')
sources = {
    'nircmd': 'https://www.nirsoft.net/utils/nircmd.html',
    'nucleo': 'https://nucleoapp.com/license',
    'yt-dlp': 'https://raw.githubusercontent.com/yt-dlp/yt-dlp/master/LICENSE',
    'yt-dlp-readme': 'https://raw.githubusercontent.com/yt-dlp/yt-dlp/master/README.md',
    'sherpa': 'https://raw.githubusercontent.com/k2-fsa/sherpa-onnx/v1.13.8/LICENSE',
    'llama': 'https://raw.githubusercontent.com/ggml-org/llama.cpp/b9763/LICENSE',
    'qdrant': 'https://raw.githubusercontent.com/qdrant/qdrant/v1.20.0/LICENSE',
    '3dspeaker': 'https://raw.githubusercontent.com/modelscope/3D-Speaker/main/LICENSE',
}
report = []
for name, url in sources.items():
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent':'Flosi-License-Review'}), timeout=25) as r:
            data = r.read()
            status = r.status
        text = data.decode('utf-8', errors='replace')
        (root/(name+'-source.txt')).write_text(text)
        if name in ['nircmd','nucleo']:
            text = re.sub(r'<script\b[^>]*>.*?</script>|<style\b[^>]*>.*?</style>', '', text, flags=re.S|re.I)
            text = html.unescape(re.sub(r'<[^>]+>',' ', text))
            text = re.sub(r'\s+',' ',text)
        snippets = []
        for term in ['License', 'license', 'Licensing', 'GPLv3', 'commercial', 'resell']:
            pos = text.find(term)
            if pos >= 0: snippets.append(text[max(0,pos-50):pos+1300])
        report.append(dict(name=name,url=url,status=status,sha256=hashlib.sha256(data).hexdigest(),snippets=snippets[:4]))
    except Exception as e:
        report.append(dict(name=name,url=url,error=str(e)))
(root/'LICENSE_SOURCES.json').write_text(json.dumps(report,indent=2)+'\n')
for r in report:
    print(r['name'], r.get('status',r.get('error')), (r.get('snippets') or [''])[0][:1700])
