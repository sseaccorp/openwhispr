import concurrent.futures
import json
import pathlib
import urllib.request

registry = json.loads(pathlib.Path('/workspace/work/flosi-baseline/src/models/modelRegistryData.json').read_text())
repos = {}
for provider in registry['localProviders']:
    for model in provider['models']:
        for key,value in model.items():
            if key.lower().endswith('hfrepo') and isinstance(value,str):
                repos.setdefault(value,[]).append(dict(model_id=model['id'],field=key))

def fetch(item):
    repo, models = item
    url = 'https://huggingface.co/api/models/'+repo
    try:
        with urllib.request.urlopen(url,timeout=20) as r: data=json.load(r)
        card=data.get('cardData') or {}
        return dict(repo=repo,models=models,url=url,sha=data.get('sha'),gated=data.get('gated'),
                    license=card.get('license'),license_name=card.get('license_name'),license_link=card.get('license_link'))
    except Exception as e:
        return dict(repo=repo,models=models,url=url,error=str(e))

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    records=list(pool.map(fetch,sorted(repos.items())))
pathlib.Path('/workspace/work/flosi-phase2/GGUF_LICENSES.json').write_text(json.dumps(records,indent=2)+'\n')
for record in records:
    print(record['repo'],record.get('license'),record.get('license_name'),record.get('error',''))
