$QaFailures = @()
Get-ChildItem /workspace/work/flosi-phase2/powershell-blocks/*.ps1 | ForEach-Object {
    $QaTokens = $null
    $QaErrors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$QaTokens, [ref]$QaErrors) | Out-Null
    foreach ($QaParseError in $QaErrors) {
        $QaFailures += "$($_.Name):$($QaParseError.Extent.StartLineNumber): $($QaParseError.Message)"
    }
}
if ($QaFailures.Count) { $QaFailures; exit 1 }
'All PowerShell documentation blocks parsed; OS-specific behavior not executed.'
