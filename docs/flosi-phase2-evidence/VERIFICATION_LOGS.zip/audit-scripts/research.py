import json
import pathlib
import urllib.request

root = pathlib.Path('/workspace/work/flosi-phase2')
prior = json.loads(pathlib.Path('/workspace/work/flosi-baseline/docs/flosi-evidence/NPM_AUDIT.json').read_text())
ids = sorted({a['url'].split('/')[-1] for v in prior['vulnerabilities'].values()
              for a in v['via'] if isinstance(a, dict)})
results = []
for ghsa in ids:
    url = 'https://api.github.com/advisories/' + ghsa
    try:
        request = urllib.request.Request(url, headers={'User-Agent':'Flosi-Security-Review', 'Accept':'application/vnd.github+json'})
        with urllib.request.urlopen(request, timeout=20) as response:
            data = json.load(response)
        results.append(data)
        print(ghsa, data.get('severity'), data.get('summary'))
    except Exception as error:
        results.append(dict(ghsa_id=ghsa, source_url=url, error=str(error)))
        print(ghsa, str(error))
(root / 'ADVISORIES.json').write_text(json.dumps(results,indent=2)+'\n')
