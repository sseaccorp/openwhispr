$ErrorActionPreference = 'Stop'
$repo = '/workspace/work/flosi-mvp'
$files = @((Join-Path $repo 'scripts/flosi-qa.ps1'))
$text = Get-Content -Raw -LiteralPath (Join-Path $repo 'docs/FLOSI_MVP_WINDOWS_QUICKSTART.md')
$index = 0
foreach ($match in [regex]::Matches($text, '(?s)```powershell\r?\n(.*?)```')) {
    $target = "/workspace/work/flosi-mvp-audit/quickstart-$index.ps1"
    [IO.File]::WriteAllText($target, $match.Groups[1].Value)
    $files += $target
    $index++
}
foreach ($file in $files) {
    $tokens = $null; $errors = $null
    $null = [Management.Automation.Language.Parser]::ParseFile($file, [ref]$tokens, [ref]$errors)
    if ($errors.Count) { throw ($errors | Out-String) }
}
@{ parsed = $files.Count; quickstartBlocks = $index; executedWindowsCommands = $false; parser = $PSVersionTable.PSVersion.ToString() } | ConvertTo-Json -Compress
