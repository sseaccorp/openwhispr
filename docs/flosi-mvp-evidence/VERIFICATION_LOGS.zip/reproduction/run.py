import datetime
import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path('/workspace/work/flosi-mvp-audit')
name, cwd, command = sys.argv[1:4]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
log = root / 'logs' / (name + '.log')
with log.open('w') as out:
    out.write(f'command: {command}\ncwd: {cwd}\nstarted_utc: {started}\n\n')
    out.flush()
    p = subprocess.run(command, shell=True, executable='/bin/bash', cwd=cwd,
                       stdout=out, stderr=subprocess.STDOUT)
record = dict(name=name, command=command, cwd=cwd, started_utc=started,
              seconds=round(time.monotonic()-t0, 2), exit_code=p.returncode,
              log=str(log))
with (root / 'commands.jsonl').open('a') as out:
    out.write(json.dumps(record) + '\n')
print(json.dumps(record))
lines = [line for line in log.read_text().splitlines() if not line.strip().startswith('Downloading:')]
print('\n'.join(lines)[-3500:])
