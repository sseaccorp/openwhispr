Synthetic fixtures, generated only for this task with ffmpeg/libflite (not user audio).
ffmpeg -nostdin -hide_banner -loglevel error -f lavfi -i "flite=text='Um can you send me the PostgreSQL report by Friday at five thirty':voice=slt" -ar 16000 -ac 1 -c:a pcm_s16le -n english.wav
ffmpeg -nostdin -hide_banner -loglevel error -f lavfi -i "flite=text='Um can you send me the report by Friday':voice=slt" -ar 16000 -ac 1 -c:a pcm_s16le -n english-clear.wav
The two WAVs are fixtures, not the Windows microphone or desktop.
