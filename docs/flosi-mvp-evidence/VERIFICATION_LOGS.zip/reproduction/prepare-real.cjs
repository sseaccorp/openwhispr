const fs=require('node:fs'),path=require('node:path');
const repo='/workspace/work/flosi-mvp',root='/workspace/work/flosi-mvp-audit/real';
const {pathsFor,QA}=require(repo+'/src/helpers/flosiQa/identity');const paths=pathsFor(root);
const {installPack,saveManifest}=require(repo+'/scripts/flosi-qa');const {downloadPinned}=require(repo+'/scripts/flosi-qa-download');const {addQwen,verifyQwen}=require(repo+'/scripts/flosi-qa-qwen');
(async()=>{
 if(fs.existsSync(path.join(paths.userData,'sidecar-pids/llama.pid'))) throw Error('Wait for this task native test to close its sidecars');
 // This fixture root was created solely by the current task, with synthetic
 // audio and newly downloaded public models. It is not an existing user root.
 if(!fs.existsSync(paths.marker))fs.writeFileSync(paths.marker,JSON.stringify({...QA,root}),{flag:'wx'});
 saveManifest(paths,'uncommitted-linux-preparation-boundary-fixture');
 await addQwen(repo,paths,'uncommitted-linux-preparation-boundary-fixture',{installPack,downloadPinned,saveManifest});
 const receipt=verifyQwen(repo,paths);
 await addQwen(repo,paths,'uncommitted-linux-preparation-boundary-fixture',{installPack,downloadPinned,saveManifest});
 fs.writeFileSync('/workspace/work/flosi-mvp-audit/preparation-real-result.json',JSON.stringify({platform:process.platform,windowsRuntimeExecuted:false,receipt,incrementalRetryVerified:true},null,2));
 console.log(JSON.stringify({model:receipt.model.id,sha256:receipt.model.sha256,runtime:receipt.runtime.version,files:receipt.runtime.files.length,windowsRuntimeExecuted:receipt.runtime.probe.executed,incrementalRetryVerified:true}));
})().catch(e=>{console.error(e);process.exitCode=1});
