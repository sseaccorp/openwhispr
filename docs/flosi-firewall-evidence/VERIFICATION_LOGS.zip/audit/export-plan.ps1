. /workspace/work/flosi-firewall-fix/scripts/lib/flosi-qa-firewall.ps1
@(Get-FlosiFirewallPlan 'C:\FlosiQA-private\resources\bin\sherpa-onnx-ws-win32-x64.exe') | ConvertTo-Json -Depth 5
