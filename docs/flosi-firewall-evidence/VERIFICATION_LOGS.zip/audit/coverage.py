import subprocess,os,json,ipaddress,pathlib
root=pathlib.Path('/workspace/work/flosi-firewall-audit')
env=dict(os.environ,XDG_DATA_HOME=str(root/'ps-data'),XDG_CONFIG_HOME=str(root/'ps-config'),XDG_CACHE_HOME=str(root/'ps-cache'))
p=subprocess.run(['/workspace/work/flosi-orukeet-audit/powershell/pwsh','-NoProfile','-NonInteractive','-File',str(root/'export-plan.ps1')],capture_output=True,text=True,env=env,check=True)
plan=json.loads(p.stdout)
assert len(plan)==4 and len({s['Name'] for s in plan})==4
for spec in plan:
 nets=[ipaddress.ip_network(x,strict=True) for x in spec['Remote']]
 assert all(n.prefixlen>0 for n in nets)
 assert all(n.version==(4 if spec['Family']=='IPv4' else 6) for n in nets)
 ranges=sorted((int(n.network_address),int(n.broadcast_address)) for n in nets)
 merged=[]
 for lo,hi in ranges:
  if merged and lo<=merged[-1][1]+1:merged[-1][1]=max(hi,merged[-1][1])
  else:merged.append([lo,hi])
 if spec['Family']=='IPv4':
  expected=[[0,int(ipaddress.ip_address('127.0.0.0'))-1],[int(ipaddress.ip_address('128.0.0.0')),2**32-1]]
 else:expected=[[2,2**128-1]]
 assert merged==expected,(spec['Name'],merged)
 for addr in ['127.0.0.1','127.255.255.255'] if spec['Family']=='IPv4' else ['::1']:
  assert not any(ipaddress.ip_address(addr) in n for n in nets)
result={'rules':len(plan),'ipv4CIDRs':len(plan[0]['Remote']),'ipv6CIDRs':len(plan[1]['Remote']),'exactIntervalCoverage':True,'IPv4LoopbackExcluded':True,'IPv6LoopbackExcluded':True,'nativeWindowsVerified':False}
(root/'coverage.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
