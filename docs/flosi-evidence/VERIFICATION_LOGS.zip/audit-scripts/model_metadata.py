import json
import urllib.request

models = [
    'oruk/orukeet/revision/55a984d46f68323301837194ce647c702f55facc',
    'nvidia/parakeet-tdt-0.6b-v3',
    'CohereLabs/cohere-transcribe-03-2026',
    'ggerganov/whisper.cpp',
    'sentence-transformers/all-MiniLM-L6-v2',
    'pyannote/segmentation-3.0',
]
for model in models:
    url = 'https://huggingface.co/api/models/' + model
    try:
        with urllib.request.urlopen(url, timeout=30) as response:
            data = json.load(response)
            card = data.get('cardData') or {}
            print(json.dumps(dict(url=url, status=response.status, id=data.get('id'),
                sha=data.get('sha'), gated=data.get('gated'),
                license=card.get('license'), license_name=card.get('license_name'),
                license_link=card.get('license_link')), ensure_ascii=False))
    except Exception as error:
        print(json.dumps(dict(url=url, error=str(error))))
