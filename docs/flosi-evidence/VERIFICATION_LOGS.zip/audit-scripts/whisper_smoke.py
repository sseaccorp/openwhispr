"""Smoke de CPU con silencio sintético; no es una medida de precisión ni paridad."""
import json
import pathlib
import subprocess
import time
import urllib.request
import wave

root = pathlib.Path('/workspace/work/flosi-audit')
repo = pathlib.Path('/workspace/work/flosi-baseline')
audio = root / 'silence-2s.wav'
with wave.open(str(audio), 'wb') as f:
    f.setnchannels(1)
    f.setsampwidth(2)
    f.setframerate(16000)
    f.writeframes(b'\0\0' * 32000)
log = (root / 'whisper-server-smoke.txt').open('w')
args = [str(repo / 'resources/bin/whisper-server-linux-x64'), '--model',
        str(root / 'ggml-tiny.bin'), '--host', '127.0.0.1', '--port', '18973',
        '--threads', '4', '--no-gpu']
process = subprocess.Popen(args, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
try:
    ready = False
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f'whisper-server exited {process.returncode}')
        try:
            with urllib.request.urlopen('http://127.0.0.1:18973/health', timeout=2) as res:
                ready = res.status == 200
            if ready:
                break
        except Exception:
            time.sleep(.15)
    if not ready:
        raise RuntimeError('health timeout')
    # CLI/API smoke explícito: no emula todos los campos del pipeline del producto.
    started = time.monotonic()
    response = subprocess.run(['curl', '--fail', '--silent', '--show-error', '--max-time', '45',
        'http://127.0.0.1:18973/inference', '-F', f'file=@{audio}',
        '-F', 'response_format=json', '-F', 'language=en'],
        capture_output=True, text=True, check=True)
    result = json.loads(response.stdout)
    print(json.dumps(dict(kind='synthetic-silence-cpu-smoke', health=200,
        inference_seconds=round(time.monotonic()-started, 3), response=result,
        accuracy_measured=False, product_e2e=False), ensure_ascii=False))
finally:
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
    log.close()
